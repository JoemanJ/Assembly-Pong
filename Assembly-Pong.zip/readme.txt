INSTRUÇÕES DE COMPILAÇÃO:

0 - O arquivo "vai.bat" é um script que pode ser executado pelo DOSBOX para automatizar todo o processo descrito abaixo.

1 - Compilar os arquivos fonte com o programa Nasm: game.asm, setup.asm, fblock.asm, circle.asm, fcircle.asm, line.asm, plot_xy.asm, cursor.asm, caracter.asm

2 - Linkar os arquivos fonte gerados usando o script link.bat através do ambiente DOSBOX: LINK.BAT

3 - Executar o programa gerado: GAME.EXE

CONTROLES:

W, S = Controles do jogador 1
seta cima, seta baixo = Controles do jogador 2, contole do menu
Enter = Selecionar dificuldade no menu
P = Pausar/despausar jogo
Q = Sair do jogo
Y = Confirmar
N = Negar
